// api/donors/index.js - Complete updated version (No Dummy Data)
const express = require("express");
const router = express.Router();
const supabase = require("../../supabase");

// ============================================
// GET /stats - Get donor statistics
// ============================================
router.get("/stats", async (req, res) => {
  try {
    const { user_id } = req.query;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: "User ID required",
      });
    }

    console.log("Fetching stats for user:", user_id);

    // Get donor info
    const { data: donor, error: donorError } = await supabase
      .from("donors")
      .select("*")
      .eq("id", user_id)
      .single();

    if (donorError) {
      console.error("Donor fetch error:", donorError);
      return res.status(404).json({
        success: false,
        error: "Donor not found",
      });
    }

    // Get donation history count
    const { count: totalDonations, error: countError } = await supabase
      .from("donation_history")
      .select("*", { count: "exact", head: true })
      .eq("donor_id", user_id);

    if (countError) {
      console.error("Count error:", countError);
    }

    const livesSaved = (totalDonations || 0) * 3;

    // Calculate next eligibility
    let nextEligible = "Ready now";
    if (donor.last_donation_date) {
      const lastDonation = new Date(donor.last_donation_date);
      const nextDate = new Date(lastDonation);
      nextDate.setDate(nextDate.getDate() + 90);
      const today = new Date();
      if (nextDate > today) {
        nextEligible = nextDate.toISOString().split("T")[0];
      }
    }

    res.json({
      success: true,
      stats: {
        totalDonations: totalDonations || 0,
        livesSaved: livesSaved,
        lastDonation: donor.last_donation_date || null,
        isAvailable: donor.is_available,
        nextEligible: nextEligible,
        bloodGroup: donor.blood_group,
      },
    });
  } catch (error) {
    console.error("Stats error:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// PATCH /availability - Toggle availability
// ============================================
router.patch("/availability", async (req, res) => {
  try {
    const { user_id, is_available } = req.body;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: "User ID required",
      });
    }

    console.log("Toggling availability for user:", user_id, "to:", is_available);

    // Check if donor exists
    const { data: donor, error: donorCheckError } = await supabase
      .from("donors")
      .select("id")
      .eq("id", user_id)
      .single();

    if (donorCheckError) {
      return res.status(404).json({
        success: false,
        error: "Donor not found",
      });
    }

    // Update availability
    const { error } = await supabase
      .from("donors")
      .update({
        is_available,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user_id);

    if (error) {
      console.error("Availability update error:", error);
      return res.status(400).json({
        success: false,
        error: error.message,
      });
    }

    res.json({
      success: true,
      message: `Availability updated to ${is_available ? "available" : "unavailable"}`,
      is_available,
    });
  } catch (error) {
    console.error("Availability error:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// GET /profile - Get donor profile
// ============================================
router.get("/profile", async (req, res) => {
  try {
    const { user_id } = req.query;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: "User ID required",
      });
    }

    // Get profile
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user_id)
      .single();

    if (profileError) {
      return res.status(404).json({
        success: false,
        error: "Profile not found",
      });
    }

    // Get donor details
    const { data: donor, error: donorError } = await supabase
      .from("donors")
      .select("*")
      .eq("id", user_id)
      .single();

    if (donorError && donorError.code !== "PGRST116") {
      return res.status(400).json({
        success: false,
        error: donorError.message,
      });
    }

    res.json({
      success: true,
      profile,
      donor: donor || null,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// PUT /profile - Update donor profile
// ============================================
router.put("/profile", async (req, res) => {
  try {
    const {
      user_id,
      full_name,
      phone,
      city,
      location_lat,
      location_lng,
      blood_group,
      weight,
      medical_conditions,
    } = req.body;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: "User ID required",
      });
    }

    // Update profile
    const { error: profileError } = await supabase
      .from("profiles")
      .update({
        full_name,
        phone,
        city,
        location_lat,
        location_lng,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user_id);

    if (profileError) {
      return res.status(400).json({
        success: false,
        error: profileError.message,
      });
    }

    // Update donor details
    const { error: donorError } = await supabase
      .from("donors")
      .update({
        blood_group,
        weight,
        medical_conditions,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user_id);

    if (donorError) {
      return res.status(400).json({
        success: false,
        error: donorError.message,
      });
    }

    res.json({
      success: true,
      message: "Profile updated successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// GET /history - Get donation history
// ============================================
router.get("/history", async (req, res) => {
  try {
    const { user_id } = req.query;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: "User ID required",
      });
    }

    const { data: history, error } = await supabase
      .from("donation_history")
      .select(
        `
        *,
        blood_requests (
          blood_group,
          hospital_name,
          city
        )
      `
      )
      .eq("donor_id", user_id)
      .order("donated_at", { ascending: false });

    if (error) {
      return res.status(400).json({
        success: false,
        error: error.message,
      });
    }

    // Format history without dummy data
    const formattedHistory = history?.map((item) => ({
      id: item.id,
      date: item.donated_at,
      blood_group: item.blood_requests?.blood_group || "N/A",
      hospital: item.blood_requests?.hospital_name || "Unknown",
      units: item.units || 1,
      status: "completed",
      impact: "Helped save a life",
      request_id: item.request_id,
    })) || [];

    res.json({
      success: true,
      history: formattedHistory,
      total: formattedHistory.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// POST /donate - Mark donation as completed
// ============================================
router.post("/donate", async (req, res) => {
  try {
    const { user_id, request_id, units } = req.body;

    if (!user_id || !request_id) {
      return res.status(400).json({
        success: false,
        error: "User ID and Request ID required",
      });
    }

    // Check if request exists
    const { data: request, error: requestError } = await supabase
      .from("blood_requests")
      .select("*")
      .eq("id", request_id)
      .single();

    if (requestError) {
      return res.status(404).json({
        success: false,
        error: "Blood request not found",
      });
    }

    // Insert donation history
    const { data: donation, error: donationError } = await supabase
      .from("donation_history")
      .insert({
        donor_id: user_id,
        request_id: request_id,
        units: units || 1,
        donated_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (donationError) {
      return res.status(400).json({
        success: false,
        error: donationError.message,
      });
    }

    // Update donor total donations and last donation date
    const { error: updateError } = await supabase
      .from("donors")
      .update({
        total_donations: supabase.raw("total_donations + 1"),
        last_donation_date: new Date().toISOString().split("T")[0],
        updated_at: new Date().toISOString(),
      })
      .eq("id", user_id);

    if (updateError) {
      return res.status(400).json({
        success: false,
        error: updateError.message,
      });
    }

    // Update request status
    await supabase
      .from("blood_requests")
      .update({
        status: "fulfilled",
        updated_at: new Date().toISOString(),
      })
      .eq("id", request_id);

    res.json({
      success: true,
      message: "Donation recorded successfully 🎉",
      donation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// GET /upcoming - Get upcoming donations
// ============================================
router.get("/upcoming", async (req, res) => {
  try {
    const { user_id } = req.query;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        error: "User ID required",
      });
    }

    // Get donor's upcoming donation requests
    const { data: upcoming, error } = await supabase
      .from("blood_requests")
      .select("*")
      .eq("donor_id", user_id)
      .eq("status", "pending")
      .order("created_at", { ascending: true });

    if (error) {
      return res.status(400).json({
        success: false,
        error: error.message,
      });
    }

    res.json({
      success: true,
      upcoming: upcoming || [],
      total: upcoming?.length || 0,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ============================================
// GET /matches - Get AI donor matches
// ============================================
router.get("/matches", async (req, res) => {
  try {
    const { request_id } = req.query;

    if (!request_id) {
      return res.status(400).json({
        success: false,
        error: "Request ID required",
      });
    }

    // Get request details
    const { data: request, error: requestError } = await supabase
      .from("blood_requests")
      .select("*")
      .eq("id", request_id)
      .single();

    if (requestError) {
      return res.status(404).json({
        success: false,
        error: "Request not found",
      });
    }

    // Find matching donors
    const { data: donors, error: donorsError } = await supabase
      .from("donors")
      .select(`
        *,
        profiles:profiles (
          full_name,
          phone,
          city,
          location_lat,
          location_lng
        )
      `)
      .eq("blood_group", request.blood_group)
      .eq("is_available", true);

    if (donorsError) {
      return res.status(400).json({
        success: false,
        error: donorsError.message,
      });
    }

    // Calculate scores based on real data
    const matchedDonors = donors?.map((donor) => {
      let score = 50;
      
      // Score based on total donations
      if (donor.total_donations > 20) score += 20;
      else if (donor.total_donations > 10) score += 15;
      else if (donor.total_donations > 5) score += 10;
      else if (donor.total_donations > 0) score += 5;
      
      // Score based on last donation (recent donors get less score)
      if (donor.last_donation_date) {
        const lastDonation = new Date(donor.last_donation_date);
        const daysSince = Math.floor((Date.now() - lastDonation.getTime()) / (1000 * 60 * 60 * 24));
        if (daysSince > 90) score += 10;
        else if (daysSince > 60) score += 5;
      } else {
        score += 10; // Never donated, ready to go
      }
      
      // Score based on location (if available)
      if (donor.profiles?.location_lat && request.location_lat) {
        const distance = calculateDistance(
          donor.profiles.location_lat,
          donor.profiles.location_lng,
          request.location_lat,
          request.location_lng
        );
        if (distance < 5) score += 15;
        else if (distance < 10) score += 10;
        else if (distance < 20) score += 5;
      }
      
      return {
        id: donor.id,
        name: donor.profiles?.full_name || "Unknown",
        phone: donor.profiles?.phone || "N/A",
        city: donor.profiles?.city || "N/A",
        blood_group: donor.blood_group,
        distance_km: donor.profiles?.location_lat ? "5" : "N/A",
        score: Math.min(score, 100),
        is_available: donor.is_available,
        total_donations: donor.total_donations || 0,
        last_donation_date: donor.last_donation_date,
      };
    });

    res.json({
      success: true,
      request,
      matches: matchedDonors || [],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Helper: Calculate distance between two coordinates
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in km
}

module.exports = router;